from typing import TypedDict

class GraphState(TypedDict):
    question: str
    mode: str
    response: str