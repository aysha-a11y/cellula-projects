from langgraph.graph import StateGraph, END
from graph.state import GraphState
from graph.nodes import router_node, generate_node, explain_node, final_node


def build_graph():
    graph = StateGraph(GraphState)

    # Nodes
    graph.add_node("router", router_node)
    graph.add_node("generate", generate_node)
    graph.add_node("explain", explain_node)
    graph.add_node("final", final_node)

    # Entry
    graph.set_entry_point("router")

    # Routing logic
    def route_decision(state):
        return state["mode"]

    graph.add_conditional_edges(
        "router",
        route_decision,
        {
            "generate": "generate",
            "explain": "explain"
        }
    )

    # Flow
    graph.add_edge("generate", "final")
    graph.add_edge("explain", "final")
    graph.add_edge("final", END)

    return graph.compile()