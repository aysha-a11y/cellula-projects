from rag.llm import llm_call

# Router Node
def router_node(state):
    question = state["question"].lower()

    if any(word in question for word in ["explain", "why", "how"]):
        return {"mode": "explain"}
    else:
        return {"mode": "generate"}


# Generate Node
def generate_node(state):
    question = state["question"]

    response = llm_call(f"Generate a detailed answer: {question}")

    return {"response": response}


# Explain Node
def explain_node(state):
    question = state["question"]

    response = llm_call(f"Explain this in simple terms: {question}")

    return {"response": response}


# Final Node
def final_node(state):
    return state