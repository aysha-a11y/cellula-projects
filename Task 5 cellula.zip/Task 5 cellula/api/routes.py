from fastapi import APIRouter
from pydantic import BaseModel
from graph.graph_builder import build_graph

router = APIRouter()
graph = build_graph()


class QueryRequest(BaseModel):
    prompt: str


@router.post("/query")
def query_handler(request: QueryRequest):
    result = graph.invoke({
        "question": request.prompt
    })

    return {
        "mode": result["mode"],
        "response": result["response"]
    }